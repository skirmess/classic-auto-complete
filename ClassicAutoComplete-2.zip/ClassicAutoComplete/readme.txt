
Restores the classic auto complete functionality of the send mail
frame and adds your alts to the list used for auto completion. 

*** Changelog

Version 2
Bugfix: Don't add an alt to the list if the alt is also in the guild

Version 1
Initial release

