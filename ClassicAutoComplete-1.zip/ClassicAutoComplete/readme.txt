
Restores the classic auto complete functionality of the send mail
frame and adds your alts to the list used for auto completion. 

*** Changelog

Version 1
Initial release

