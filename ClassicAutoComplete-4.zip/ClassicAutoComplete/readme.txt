
Restores the classic auto complete functionality of the send mail
frame and adds your alts to the list used for auto completion. 

*** Changelog

Updated TOC for WoW 3.2
Added license information
Added link to project main page at
http://code.google.com/p/classic-auto-complete/

Version 3
Bugfix: Call SendMailFrame_Update() after every new character. This fixes an issue where it was not always possible to send a mail although it should have been.

Version 2
Bugfix: Don't add an alt to the list if the alt is also in the guild

Version 1
Initial release

